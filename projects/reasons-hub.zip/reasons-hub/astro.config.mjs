import { defineConfig } from 'astro/config';

// https://astro.build/config
export default defineConfig({
  site: 'https://northernterritory.com',
  output: 'static',
});
